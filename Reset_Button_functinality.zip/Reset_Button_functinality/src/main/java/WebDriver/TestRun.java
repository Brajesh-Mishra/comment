package WebDriver;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestRun {

	WebDriver driver;

@Given("^Open the firefox and  launch the application$")
public void open_the_firefox_and_launch_the_application() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

	System.setProperty("webdriver.chrome.driver", "C:\\Users\\BRAJMISH\\Documents\\module3\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file:///C:/Users/BRAJMISH/Documents/module3/WorkingWithForms.html");

	// throw new PendingException();
}

@When("^Enter the details$")
public void enter_the_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	driver.findElement(By.id("txtUserName")).sendKeys("brajesh");
	Thread.sleep(1000);
	
	driver.findElement(By.name("txtPwd")).sendKeys("brajesh");
	Thread.sleep(1000);
	
	driver.findElement(By.className("Format")).sendKeys("brajesh");
	Thread.sleep(1000);
	
	driver.findElement(By.cssSelector("input.Format1")).sendKeys("brajesh");
	Thread.sleep(1000);
	
	driver.findElement(By.id("txtLastName")).sendKeys("mishra	");
	Thread.sleep(1000);
	
	driver.findElement(By.id("rbMale")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.id("DOB")).sendKeys("15/02/19");
	Thread.sleep(1000);
	
	driver.findElement(By.id("txtEmail")).sendKeys("brajesh@gmail.com");
	Thread.sleep(1000);
	
	driver.findElement(By.id("txtAddress")).sendKeys("capgemini india");
	Thread.sleep(1000);
	
	Select option=new Select(driver.findElement(By.name("City")));
	option.selectByVisibleText("Pune");;
	Thread.sleep(1000);
	
	driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("7895930092");
	Thread.sleep(1000);
	
	// driver.findElement(By.name("chkHobbies")).click();;
	List<WebElement> list=driver.findElements(By.name("chkHobbies"));
	for(WebElement iteam:list)
		 iteam.click();
	//driver.findElement(By.cssSelector("input[value='Movies']")).click();
	Thread.sleep(1000);
	

	
	// throw new PendingException();
}

@Then("^Submit the data$")
public void submit_the_data() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	driver.findElement(By.name("submit")).click();;
	Thread.sleep(1000);

	// throw new PendingException();
}

@Then("^Reset the form$")
public void reset_the_form() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	driver.findElement(By.name("reset")).click();;
	Thread.sleep(1000);

	// throw new PendingException();
}

@When("^Enter the usrename\"([^\"]*)\" and password\"([^\"]*)\" and conPass\"([^\"]*)\" and firstname\"([^\"]*)\" lastname\"([^\"]*)\"and gender\"([^\"]*)\" and dob\"([^\"]*)\" and email\"([^\"]*)\" and address\"([^\"]*)\" and city\"([^\"]*)\" and phone\"([^\"]*)\" and hobbies\"([^\"]*)\"$")
public void enter_the_usrename_and_password_and_conPass_and_firstname_lastname_and_gender_and_dob_and_email_and_address_and_city_and_phone_and_hobbies(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	driver.findElement(By.id("txtUserName")).sendKeys(arg1);
	Thread.sleep(1000);
	
	driver.findElement(By.name("txtPwd")).sendKeys(arg2);
	Thread.sleep(1000);
	
	driver.findElement(By.className("Format")).sendKeys(arg3);
	Thread.sleep(1000);
	
	driver.findElement(By.cssSelector("input.Format1")).sendKeys(arg4);
	Thread.sleep(1000);
	
	driver.findElement(By.id("txtLastName")).sendKeys(arg5);
	Thread.sleep(1000);
	
	driver.findElement(By.id("rbMale")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.id("DOB")).sendKeys(arg7);
	Thread.sleep(1000);
	
	driver.findElement(By.id("txtEmail")).sendKeys(arg8);
	Thread.sleep(1000);
	
	driver.findElement(By.id("txtAddress")).sendKeys(arg9);
	Thread.sleep(1000);
	
	Select option=new Select(driver.findElement(By.name("City")));
	option.selectByVisibleText(arg10);
	Thread.sleep(1000);
	
	driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys(arg11);
	Thread.sleep(1000);
	
	// driver.findElement(By.name("chkHobbies")).click();;
	//List<WebElement> list=driver.findElements(By.name("chkHobbies"));
	//for(WebElement iteam:list)
		// iteam.click();
	driver.findElement(By.cssSelector("input[value="+arg12+"]")).click();
	Thread.sleep(1000);
	
   // throw new PendingException();
}

@Then("^verification is done$")
public void verification_is_done() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    //throw new PendingException();
	driver.findElement(By.name("submit")).click();;
	Thread.sleep(1000);

}
	




}
