package Exercise;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBin.FactoryDefination;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
WebDriver driver;
FactoryDefination  pageFactory;	

@Given("^User is on login page$")
public void user_is_on_login_page() throws Throwable {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\BRAJMISH\\Documents\\module3\\chromedriver.exe");
	driver = new ChromeDriver();
	pageFactory=new FactoryDefination(driver);
	driver.get("file:///C:/Users/BRAJMISH/Documents/module3/login.html");
}

@Then("^check the title of the page$")
public void check_the_title_of_the_page() throws Throwable {
	
	String title=driver.getTitle();
	if(title.contentEquals("Login"))
		System.out.println("***Title Is Matched***");
	else
		System.out.println("***Title Is Not Matched***");
	driver.close();

}

@When("^user enters valid username and password and clicks the Login button$")
public void user_enters_valid_username_and_password() throws Throwable {
	pageFactory.setPfUserName("capgemini");	Thread.sleep(1000);
	pageFactory.setPfPassword("capg1234"); Thread.sleep(1000);
	pageFactory.setPfButton(); Thread.sleep(1000);
	
	
}

@Then("^navigate to welcome page$")
public void navigate_to_welcome_page() throws Throwable {
	
	 driver.navigate().to("C:\\Users\\BRAJMISH\\Documents\\module3\\success.html");  Thread.sleep(1000);
	 driver.close();

  }

@When("^user leaves username blank$")
public void user_leaves_username_blank() throws Throwable {
	pageFactory.setPfUserName("");	Thread.sleep(1000);
  }

@When("^clicks the login button$")
public void clicks_the_login_button() throws Throwable {
	pageFactory.setPfButton();	Thread.sleep(1000);
	driver.close();

}


@When("^user leaves password blank and clicks the login button$")
public void user_leaves_password_blank() throws Throwable {
	pageFactory.setPfUserName("brajesh"); Thread.sleep(100);
	pageFactory.setPfPassword(""); Thread.sleep(100);
	pageFactory.setPfButton(); Thread.sleep(1000);
	driver.close();
  }



@When("^user enter incorrect username and password and clicks the button and show alert message$")
public void user_enter_incorrect_username_and_password(DataTable arg1) throws Throwable {
	List<List<String>> list = arg1.raw();
	for(int i=0;i<list.size();i++)
	{
		driver.findElement(By.name("userName")).clear();

		driver.findElement(By.name("userPwd")).clear();
		pageFactory.setPfUserName(list.get(i).get(0)); Thread.sleep(1000);
		pageFactory.setPfPassword(list.get(i).get(1)); Thread.sleep(1000);
	}
		/*pageFactory.setPfButton();Thread.sleep(100);
		Alert alert=driver.switchTo().alert();
		alert.accept();
		System.out.println("*********"+alert.getText());
		*/
		//driver.close();
		
	}
	/*for(List<String> item :   list)
	{
		pageFactory.setPfUserName(item.get(0)); Thread.sleep(100);
		pageFactory.setPfPassword(item.get(1)); Thread.sleep(100);
		pageFactory.setPfButton();Thread.sleep(100);
		Alert alert=driver.switchTo().alert();
		System.out.println("*********"+alert.getText());
		alert.accept();
		driver.close();
	}
	*/
  




@When("^user enter incorrect username \"([^\"]*)\" and password\"([^\"]*)\"$")
public void user_enter_incorrect_username_and_password(String arg1, String arg2) throws Throwable {
		pageFactory.setPfUserName(arg1);	Thread.sleep(100);
		pageFactory.setPfPassword(arg2);	Thread.sleep(100);
		
}

@When("^clicks the button$")
public void clicks_the_button() throws Throwable {
	pageFactory.setPfButton();	Thread.sleep(1000);
	Alert alert=driver.switchTo().alert();
	System.out.println("*********"+alert.getText());
	alert.accept();
	driver.close();
  }



}
