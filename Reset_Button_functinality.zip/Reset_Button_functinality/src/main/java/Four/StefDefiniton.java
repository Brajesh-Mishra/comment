package Four;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBin.HotelBookingFactory;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StefDefiniton {

WebDriver driver;
HotelBookingFactory hotelBooking;



@Given("^Usre is on hotel booking page$")
public void usre_is_on_hotel_booking_page() throws Throwable {
    
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\BRAJMISH\\Documents\\module3\\chromedriver.exe");
	driver = new ChromeDriver();
	//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	hotelBooking=new HotelBookingFactory();
	driver.get("file:///C:/Users/BRAJMISH/Documents/module3/hotelbooking.html");
	
	}

@Then("^check the title of the page$")
public void check_the_title_of_the_page() throws Throwable {
    
	String title=driver.getTitle();
	
	if(title.contentEquals("Hotel Booking"))
		System.out.println("***Title Is Matched***");
	else
		System.out.println("***Title Is Not Matched***");
	
	//driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	driver.close();
	
	
	}

@When("^user enters all valid data$")
public void user_enters_all_valid_data() throws Throwable {
    System.out.println("Eneters ");
	hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("Mishra");	Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh.mishra_cs15@gla.ac.in");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092");	Thread.sleep(1000);
	hotelBooking.setPfcity("Pune");	Thread.sleep(1000); 
	hotelBooking.setPfstate("Maharashtra");	Thread.sleep(1000);	
	hotelBooking.setPfpersons(5);	Thread.sleep(1000);
	hotelBooking.setPfcardholder("Brajesh Mishra");	Thread.sleep(1000);
	hotelBooking.setPfdebit("7895-8598-7895");	Thread.sleep(1000);
	hotelBooking.setPfcvv("097");	Thread.sleep(1000);
	hotelBooking.setPfmonth("2020");	Thread.sleep(1000);
	hotelBooking.setPfyear("2021");	Thread.sleep(1000);
	//driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	hotelBooking.setPfbutton();
	
	 
}

@Then("^navigate to welcome page$")
public void navigate_to_welcome_page() throws Throwable {
    driver.navigate().to("C:\\Users\\BRAJMISH\\Documents\\module3\\success.html");  Thread.sleep(1000);
	//driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	driver.close();

}

@When("^user leaves first name blank$")
public void user_leaves_first_name_blank() throws Throwable {
    hotelBooking.setPffname("");  Thread.sleep(1000);
    
	
	
}

@When("^clicks the botton$")
public void clicks_the_botton() throws Throwable {
   hotelBooking.setPfbutton();	Thread.sleep(1000);
//   driver.close();
	
}

@Then("^display alert message$")
public void display_alert_message() throws Throwable {
    Alert alert=driver.switchTo().alert();
	System.out.println("*********"+alert.getText());
	alert.accept();
	driver.close();
	
}

@When("^user leaves last name blank and clicks the botton$")
public void user_leaves_last_name_blank_and_clicks_the_botton() throws Throwable {
    hotelBooking.setPffname("Brajesh"); Thread.sleep(1000);
	hotelBooking.setPflname("");	Thread.sleep(1000);
	hotelBooking.setPfbutton();	Thread.sleep(1000);
//	driver.close();
	
}
@When("^user enter incorrect email format and clicks the button$")
public void user_enter_incorrect_email_format_and_clicks_the_button() throws Throwable {
    System.out.println("email wala ");
    hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
  	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("");	Thread.sleep(1000);
	hotelBooking.setPfbutton();	Thread.sleep(1000);
	//driver.close();
	
}

@When("^user leaves mobileNo blank and clicks the button$")
public void user_leaves_mobileNo_blank_and_clicks_the_button() throws Throwable {
    hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("");   Thread.sleep(1000);
	hotelBooking.setPfbutton();Thread.sleep(1000);
//	driver.close();
	
}

@When("^user enter incorrect mobileNo format and clicks the button$")
public void user_enter_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
	
	
	hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);

	
	List<String> list=arg1.asList(String.class);
	hotelBooking.setPfbutton();
	
	for(int i=0; i<list.size(); i++) {
		if(Pattern.matches("^[7-9]{1}[0-9]{9}$", list.get(i)))
		{	
			//hotelBooking.setPfmobile(list.get(i));	Thread.sleep(1000);
			//hotelBooking.setPfbutton();Thread.sleep(1000);
			System.out.println("***** Matched" + list.get(i) + "*****");
//			driver.close();
		}
		else 
		{	//hotelBooking.setPfmobile(list.get(i));	
			//hotelBooking.setPfbutton();
			System.out.println("***** NOT Matched" + list.get(i) + "*****");
//			driver.close();
		}
	}
	
}

@When("^user doesnot select city$")
public void user_doesnot_select_city() throws Throwable {
    
	hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092"); Thread.sleep(1000);
	hotelBooking.setPfcity("Select City"); Thread.sleep(1000);
	hotelBooking.setPfbutton();Thread.sleep(1000);
//	driver.close();
	
}

@When("^user doesnot select state$")
public void user_doesnot_select_state() throws Throwable {
    
	hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092"); Thread.sleep(1000);
	hotelBooking.setPfcity("Pune"); Thread.sleep(1000);
	hotelBooking.setPfstate( "Select State");	Thread.sleep(1000);
	hotelBooking.setPfbutton();Thread.sleep(1000);
//	driver.close();
	
}

@When("^user enters (\\d+)$")
public void user_enters(int arg1) throws Throwable {
    
	hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092"); Thread.sleep(1000);
	hotelBooking.setPfcity("Pune"); Thread.sleep(1000);
	hotelBooking.setPfstate("Maharashtra");	Thread.sleep(1000);
	hotelBooking.setPfpersons(arg1);	Thread.sleep(1000);
	hotelBooking.setPfbutton();Thread.sleep(1000);
	driver.close();
	
	
}

@Then("^alloted rooms such that (\\d+) room for minimum (\\d+) guests$")
public void alloted_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
    if(arg2<=3)
	{
		System.out.println("room: "+1);
		assertEquals(arg1, 1);
	}
	else if(arg2<=6)
	{
		System.out.println("room: "+2);
		assertEquals(arg1, 2);

	}
	else if(arg2<=9)
	{
		System.out.println("room: "+3);
		assertEquals(arg1, 3);

	}		
	
	
}

@When("^user leaves the CardHolderName blank$")
public void user_leaves_the_CardHolderName_blank() throws Throwable {
    hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092"); Thread.sleep(1000);
	hotelBooking.setPfcity("Pune"); Thread.sleep(1000);
	hotelBooking.setPfstate("Maharashtra");	Thread.sleep(1000);
	hotelBooking.setPfpersons(3);	Thread.sleep(1000);
	hotelBooking.setPfcardholder("");  Thread.sleep(1000);
	
	//driver.close();Thread.sleep(1000);

	
}

@When("^clicks the button$")
public void clicks_the_button() throws Throwable {
    hotelBooking.setPfbutton();Thread.sleep(1000);
	//driver.close();
	
	
}

@When("^user leaves the DebitcardNo blank and clciks the button$")
public void user_leaves_the_DebitcardNo_blank_and_clciks_the_button() throws Throwable {
    hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092"); Thread.sleep(1000);
	hotelBooking.setPfcity("Pune"); Thread.sleep(1000);
	hotelBooking.setPfstate("Maharashtra");	Thread.sleep(1000);
	hotelBooking.setPfpersons(3);	Thread.sleep(1000);
	hotelBooking.setPfcardholder("Brajesh Mishra");  Thread.sleep(1000);
	hotelBooking.setPfdebit("");	Thread.sleep(1000);
	hotelBooking.setPfbutton();Thread.sleep(1000);
//	driver.close();
	
}

@When("^user leaves the expirationMonth blank and clciks the button$")
public void user_leaves_the_expirationMonth_blank_and_clciks_the_button() throws Throwable {
    hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092"); Thread.sleep(1000);
	hotelBooking.setPfcity("Pune"); Thread.sleep(1000);
	hotelBooking.setPfstate("Maharashtra");	Thread.sleep(1000);
	hotelBooking.setPfpersons(3);	Thread.sleep(1000);
	hotelBooking.setPfcardholder("Brajesh Mishra");  Thread.sleep(1000);
	hotelBooking.setPfdebit("7895-8956-7845");	Thread.sleep(1000);
	hotelBooking.setPfcvv("097");	Thread.sleep(1000);
	hotelBooking.setPfmonth("");	Thread.sleep(1000);
	hotelBooking.setPfbutton();Thread.sleep(1000);
//	driver.close();
	
}

@When("^user leaves the expirationYr blank and clciks the button$")
public void user_leaves_the_expirationYr_blank_and_clciks_the_button() throws Throwable {
    hotelBooking.setPffname("Brajesh");	Thread.sleep(1000);
	hotelBooking.setPflname("mishra");  Thread.sleep(1000);
	hotelBooking.setPfemail("brajesh@gmail.com");	Thread.sleep(1000);
	hotelBooking.setPfmobile("7895930092"); Thread.sleep(1000);
	hotelBooking.setPfcity("Pune"); Thread.sleep(1000);
	hotelBooking.setPfstate("Maharashtra");	Thread.sleep(1000);
	hotelBooking.setPfpersons(3);	Thread.sleep(1000);
	hotelBooking.setPfcardholder("Brajesh Mishra");  Thread.sleep(1000);
	hotelBooking.setPfdebit("7895-8956-7845");	Thread.sleep(1000);
	hotelBooking.setPfcvv("097");	Thread.sleep(1000);
	hotelBooking.setPfmonth("05");	Thread.sleep(1000);
	hotelBooking.setPfyear("");  Thread.sleep(1000);
	hotelBooking.setPfbutton();Thread.sleep(1000);
//	driver.close();
	
	
}



	
}
