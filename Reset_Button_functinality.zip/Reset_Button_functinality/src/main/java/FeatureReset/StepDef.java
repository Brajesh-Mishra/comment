                   package FeatureReset;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
WebDriver driver;
WebDriverWait wait;
@Given("^Open the firefox and  launch the application$")
public void open_the_firefox_and_launch_the_application() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\BRAJMISH\\Documents\\module3\\chromedriver.exe");
	 driver=new ChromeDriver();
	 driver.get("file:///C:/Users/BRAJMISH/Documents/module3/WorkingWithForms.html");
	 
	 wait=new 	WebDriverWait(driver,1000);
	 
	
	//throw new PendingException();
}

@When("^Enter the usrename and password$")
public void enter_the_usrename_and_password() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	driver.findElement(By.id("txtUserName")).sendKeys("brajesh");


	 driver.findElement(By.name("txtPwd")).sendKeys("brajesh");
	 Thread.sleep(100);
	 
	
   // throw new PendingException();
}

@Then("^Reset the crendential$")
public void reset_the_crendential() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 driver.findElement(By.name("submit")).click();;
	 Thread.sleep(100);
	 
	 
	
	//throw new PendingException();
}
	

}
